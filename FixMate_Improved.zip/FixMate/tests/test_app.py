import pytest
from app import create_app
from app.extensions import db
from app.models import User, ServiceCategory, ServiceProvider, ProviderService, Booking

class TestConfig:
    SECRET_KEY = 'test-secret'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WTF_CSRF_ENABLED = False

@pytest.fixture
def app():
    app = create_app(TestConfig)
    with app.app_context():
        db.drop_all(); db.create_all()
        customer = User(name='Test Customer', email='customer@example.com', role='customer'); customer.set_password('password')
        provider_user = User(name='Test Provider', email='provider@example.com', role='provider'); provider_user.set_password('password')
        admin = User(name='Test Admin', email='admin@example.com', role='admin'); admin.set_password('password')
        cat = ServiceCategory(name='Electrician', slug='electrician')
        db.session.add_all([customer, provider_user, admin, cat]); db.session.flush()
        provider = ServiceProvider(user_id=provider_user.id, business_name='Test Electric Services', locality='Dadar', approval_status='approved', bio='Test provider')
        db.session.add(provider); db.session.flush(); db.session.add(ProviderService(provider_id=provider.id, category_id=cat.id, name='Safety visit', price=299)); db.session.commit()
    return app

@pytest.fixture
def client(app): return app.test_client()

def login(client, email, password='password'):
    return client.post('/auth/login', data={'email': email, 'password': password}, follow_redirects=False)

def test_home_and_search(client):
    assert client.get('/').status_code == 200
    assert client.get('/browse?q=Electrician&locality=Dadar').status_code == 200

def test_auth_and_role_protection(client):
    assert client.get('/customer/dashboard').status_code == 302
    assert login(client, 'customer@example.com').status_code == 302
    assert client.get('/admin/dashboard').status_code == 403

def test_provider_and_admin_dashboard_access(client):
    login(client, 'provider@example.com'); assert client.get('/provider/dashboard').status_code == 200; assert client.get('/admin/dashboard').status_code == 403
    client.get('/auth/logout'); login(client, 'admin@example.com'); assert client.get('/admin/dashboard').status_code == 200

def test_booking_creation_and_customer_ownership(client, app):
    login(client, 'customer@example.com')
    with app.app_context(): provider = ServiceProvider.query.first(); service = provider.services[0]
    response = client.post(f'/customer/book/{provider.id}', data={'service_id': service.id, 'requested_at': '2030-01-01T10:00', 'address': 'Dadar, Mumbai', 'description': 'Repair needed'}, follow_redirects=False)
    assert response.status_code == 302
    with app.app_context(): assert Booking.query.count() == 1

def test_csrf_rejects_missing_token(client):
    client.application.config['WTF_CSRF_ENABLED'] = True
    response = client.post('/contact', data={'name':'A','email':'a@example.com','message':'A valid message without token'})
    assert response.status_code == 400
