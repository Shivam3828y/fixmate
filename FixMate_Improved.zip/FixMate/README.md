# FixMate — Local Repair & Service Finder

FixMate is an improved Flask marketplace for discovering fictional repair and home-service providers in Mumbai. This version upgrades the uploaded project in place: it keeps the original static CSS/JS design assets, removes the MySQL-only dependency, and adds a local SQLite database, secure role-based authentication, CSRF protection, booking workflow, ratings/reviews, provider approval, filters, dashboards, and reusable demo seeding.

## Features

- Customer, provider, and administrator roles using Flask-Login.
- Password hashing with Werkzeug and server-side validation.
- Flask-WTF CSRF protection on state-changing forms.
- Provider search by keyword, category, locality, rating, price, experience, and reviews.
- Provider profiles with service prices, demo ratings, experience, hours, availability, and service area.
- Customer booking requests with ownership checks and cancellation rules.
- Provider workflow: Pending → Accepted/Rejected → In Progress → Completed.
- One review per eligible completed booking, with rating and comment.
- Provider approval queue for administrators.
- Admin counts, recent bookings, users, categories, and approval management.
- SQLite by default; no MySQL server is required.
- Fictional Mumbai data: 12 categories, 40 providers, 10 customers, 25 bookings, and 20 reviews.

## Windows / VS Code setup

Open the project folder in VS Code PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python init_db.py
python seed_demo_data.py --reset
python run.py
```

Open `http://127.0.0.1:5000` in a browser.

## Demo accounts

- Admin: `admin@example.com` / `Admin123!`
- Customer: `customer1@example.com` / `Customer123!`
- Provider: `provider1@example.com` / `Provider123!`

All names, businesses, phone/email details, prices, ratings, bookings, and reviews are fictional demo records. They must not be presented as verified real businesses.

## Database and seeding

`init_db.py` creates tables without deleting existing records. `seed_demo_data.py` is idempotent when run normally. Use `python seed_demo_data.py --reset` only to explicitly reset the local demo database; never point that command at production data. The default database is `instance/fixmate.db`, which is intentionally excluded from the ZIP and Git.

To use another database, set `DATABASE_URL` in `.env`, for example:

```text
DATABASE_URL=sqlite:///fixmate.db
```

## Import 20 additional fictional providers with SQL

After initializing the database and creating the service categories, run the included `add_providers.sql` file. It adds 20 Mumbai provider records, realistic fictional email addresses using the reserved `example.com` domain, and 40 provider services. All inserted provider accounts use the password `Provider123!`.

From PowerShell in the project folder:

```powershell
python -c "import sqlite3; c=sqlite3.connect(r'instance\fixmate.db'); c.executescript(open('add_providers.sql', encoding='utf-8').read()); c.close(); print('20 providers and 40 services inserted successfully.')"
```

Verify the records:

```powershell
python -c "import sqlite3; c=sqlite3.connect(r'instance\fixmate.db'); print('Providers:', c.execute('SELECT COUNT(*) FROM service_provider').fetchone()[0]); print('Services:', c.execute('SELECT COUNT(*) FROM provider_service').fetchone()[0]); c.close()"
```

The email addresses are deliberately fictional and use `example.com`; they are not real contact addresses.

## Tests

Install dependencies and run:

```powershell
python -m pytest -q
```

The tests cover app startup, search, authentication, role restrictions, dashboards, booking creation and ownership, and CSRF rejection.

## Project structure

- `app/` — Flask application package, SQLAlchemy models, routes, templates, and preserved static assets.
- `run.py` — local development entry point.
- `init_db.py` — database table initialization.
- `seed_demo_data.py` — reusable fictional demo-data seeder.
- `add_providers.sql` — repeatable SQL import for 20 additional fictional providers and 40 services.
- `tests/` — pytest suite.
- `config.py` — environment-driven configuration.
- `.env.example` — placeholders only; no credentials.

## Security and deployment notes

This is a college-project application, not a production security claim. For deployment, replace the development secret, set secure HTTPS cookies, use a production WSGI server, add rate limiting and email verification, review database permissions, enable HTTPS, and conduct a security review. No payment processing or live GPS tracking is implemented.

## Git/GitHub

```powershell
git init
git add .
git commit -m "Improve FixMate marketplace"
git branch -M main
git remote add origin https://github.com/YOUR-ACCOUNT/YOUR-REPOSITORY.git
git push -u origin main
```

Do not commit `.env`, `.venv`, `instance/*.db`, or secrets.
