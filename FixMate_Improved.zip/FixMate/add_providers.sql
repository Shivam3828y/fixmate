PRAGMA foreign_keys = ON;
BEGIN TRANSACTION;

DROP TABLE IF EXISTS temp_demo_providers;
CREATE TEMP TABLE temp_demo_providers (
 provider_no INTEGER, provider_name TEXT, email TEXT, business_name TEXT,
 category TEXT, locality TEXT, experience INTEGER,
 service_one TEXT, price_one INTEGER, service_two TEXT, price_two INTEGER
);

INSERT INTO temp_demo_providers VALUES
(1,'Aarav Sharma','aarav.sharma@dadar-electric.example.com','Dadar Electric Care','Electrician','Dadar',8,'Wiring and switch repair',299,'Electrical safety inspection',499),
(2,'Meera Patil','meera.patil@andheri-plumbing.example.com','Andheri Plumbing Works','Plumber','Andheri West',7,'Leak and tap repair',249,'Bathroom pipe installation',699),
(3,'Rohan Desai','rohan.desai@powai-ac.example.com','Powai AC Experts','AC Repair','Powai',10,'AC general servicing',599,'AC gas refill inspection',899),
(4,'Kavya Nair','kavya.nair@thane-appliance.example.com','Thane Appliance Help','Washing Machine Repair','Thane',6,'Washing machine diagnosis',399,'Drain pump replacement',799),
(5,'Ishaan Mehta','ishaan.mehta@borivali-fridge.example.com','Borivali Fridge Clinic','Refrigerator Repair','Borivali',9,'Refrigerator inspection',399,'Cooling problem repair',899),
(6,'Neha Kulkarni','neha.kulkarni@malad-woodcraft.example.com','Malad Woodcraft','Carpenter','Malad',12,'Furniture repair visit',349,'Custom shelf installation',1299),
(7,'Vikram Joshi','vikram.joshi@goregaon-paint.example.com','Goregaon Paint Studio','Painter','Goregaon',11,'Room wall painting',999,'Wall touch-up service',499),
(8,'Anaya Shah','anaya.shah@kandivali-ro.example.com','Kandivali RO Care','RO Water Purifier Repair','Kandivali',5,'RO purifier servicing',449,'RO filter replacement',799),
(9,'Kabir Verma','kabir.verma@andheri-laptop.example.com','Andheri Laptop Lab','Laptop and Computer Repair','Andheri East',8,'Laptop diagnosis',299,'Operating system installation',599),
(10,'Pooja Iyer','pooja.iyer@navi-mumbai-cleaners.example.com','Navi Mumbai Cleaners','Home Cleaning','Navi Mumbai',6,'One-bedroom home cleaning',899,'Kitchen deep cleaning',699),
(11,'Arjun Rao','arjun.rao@dadar-pest.example.com','Dadar Pest Control','Pest Control','Dadar',7,'General pest treatment',799,'Termite inspection',599),
(12,'Simran Kapoor','simran.kapoor@powai-install.example.com','Powai Install Hub','Appliance Installation','Powai',5,'Washing machine installation',399,'TV wall mounting',699),
(13,'Dev Malhotra','dev.malhotra@borivali-electric.example.com','Borivali Electric Point','Electrician','Borivali',13,'Fan and light installation',349,'MCB replacement',599),
(14,'Riya Fernandes','riya.fernandes@thane-plumbing.example.com','Thane Plumbing Plus','Plumber','Thane',9,'Kitchen sink repair',299,'Water tank pipe repair',899),
(15,'Manav Sethi','manav.sethi@malad-cooling.example.com','Malad Cooling Solutions','AC Repair','Malad',12,'Split AC service',649,'AC electrical diagnosis',499),
(16,'Tara Menon','tara.menon@goregaon-washer.example.com','Goregaon Appliance Fix','Washing Machine Repair','Goregaon',8,'Microwave repair inspection',349,'Mixer grinder repair',249),
(17,'Yash Gupta','yash.gupta@navi-network-care.example.com','Navi Mumbai Network Care','Laptop and Computer Repair','Navi Mumbai',6,'Wi-Fi router setup',399,'Desktop troubleshooting',499),
(18,'Aditi Bansal','aditi.bansal@kandivali-homecare.example.com','Kandivali Home Care','Home Cleaning','Kandivali',5,'Bathroom deep cleaning',599,'Move-in cleaning',1499),
(19,'Sahil Khan','sahil.khan@andheri-carpenter.example.com','Andheri Carpenter Studio','Carpenter','Andheri West',10,'Door hinge repair',299,'Wardrobe repair',999),
(20,'Nisha Pillai','nisha.pillai@powai-ro.example.com','Powai RO Solutions','RO Water Purifier Repair','Powai',7,'RO annual service',499,'Water purifier installation',899);

-- All inserted accounts use the fictional demo password: Provider123!
INSERT OR IGNORE INTO "user" (name,email,password_hash,role,locality)
SELECT provider_name,email,
'scrypt:32768:8:1$nXPbGiSo20TuiQzl$c5898b73f94ee603f06938ac52a1c70fb334205844157f7fd5997bcf27c05ed93b43da6b6b507fe307071ca146b27eb06ef013bcde3936bcd7776b99f504b489',
'provider',locality
FROM temp_demo_providers;

INSERT OR IGNORE INTO service_provider
(user_id,business_name,locality,city,experience,bio,service_area,hours,available,rating,approval_status,is_demo)
SELECT u.id,d.business_name,d.locality,'Mumbai',d.experience,
'Fictional demo service provider created for FixMate testing.',
d.locality || ' and nearby Mumbai areas','9:00 AM - 7:00 PM',1,4.2,'approved',1
FROM temp_demo_providers d JOIN "user" u ON u.email=d.email;

DELETE FROM provider_service
WHERE provider_id IN (
 SELECT sp.id FROM service_provider sp JOIN "user" u ON u.id=sp.user_id
 WHERE u.email IN (SELECT email FROM temp_demo_providers)
);

INSERT INTO provider_service(provider_id,category_id,name,price)
SELECT sp.id,c.id,d.service_one,d.price_one
FROM temp_demo_providers d JOIN "user" u ON u.email=d.email
JOIN service_provider sp ON sp.user_id=u.id
JOIN service_category c ON c.name=d.category;

INSERT INTO provider_service(provider_id,category_id,name,price)
SELECT sp.id,c.id,d.service_two,d.price_two
FROM temp_demo_providers d JOIN "user" u ON u.email=d.email
JOIN service_provider sp ON sp.user_id=u.id
JOIN service_category c ON c.name=d.category;

DROP TABLE temp_demo_providers;
COMMIT;
