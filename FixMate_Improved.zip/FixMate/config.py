import os
from pathlib import Path
from dotenv import load_dotenv
BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / '.env')

def database_uri():
    """Return a portable SQLite URI, including for Windows .env files."""
    configured = os.getenv('DATABASE_URL', '').strip()
    if not configured:
        db_path = BASE_DIR / 'instance' / 'fixmate.db'
        return f"sqlite:///{db_path.as_posix()}"
    if configured.startswith('sqlite:///'):
        relative = configured[len('sqlite:///'):]
        if relative.startswith('instance/') or relative.startswith('instance\\'):
            relative = relative.split('/', 1)[-1] if '/' in relative else relative.split('\\', 1)[-1]
        if not Path(relative).is_absolute():
            db_path = BASE_DIR / 'instance' / relative
            return f"sqlite:///{db_path.as_posix()}"
    return configured

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'development-only-change-me')
    SQLALCHEMY_DATABASE_URI = database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WTF_CSRF_ENABLED = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    SESSION_COOKIE_SECURE = os.getenv('SESSION_COOKIE_SECURE', '0') == '1'
