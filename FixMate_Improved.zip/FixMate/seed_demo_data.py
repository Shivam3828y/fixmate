from datetime import datetime,timedelta
import argparse
from app import create_app
from app.extensions import db
from app.models import *
from werkzeug.security import generate_password_hash
app=create_app()
cats=['Electrician','Plumber','AC Repair','Washing Machine Repair','Refrigerator Repair','Carpenter','Painter','RO Water Purifier Repair','Laptop and Computer Repair','Home Cleaning','Pest Control','Appliance Installation']
localities=['Dadar','Andheri West','Andheri East','Borivali','Kandivali','Malad','Goregaon','Powai','Thane','Navi Mumbai']
service_words={'Electrician':['Electrical safety visit','Switch and socket repair'],'Plumber':['Minor plumbing repair','Leak inspection'],'AC Repair':['AC servicing','AC diagnosis'],'Washing Machine Repair':['Washing machine inspection','Drain pump repair'],'Refrigerator Repair':['Refrigerator inspection','Cooling diagnosis'],'Carpenter':['Carpenter visit','Furniture repair'],'Painter':['Wall painting consultation','Room touch-up'],'RO Water Purifier Repair':['RO servicing','Filter replacement'],'Laptop and Computer Repair':['Laptop diagnosis','Computer tune-up'],'Home Cleaning':['Home deep cleaning','Kitchen cleaning'],'Pest Control':['General pest control','Termite inspection'],'Appliance Installation':['Appliance installation','Wall mounting service']}
def seed(reset=False):
 with app.app_context():
  if reset: db.drop_all(); db.create_all()
  if User.query.filter_by(email='admin@example.com').first(): print('Demo data already exists; no duplicates created.'); return
  category_objs=[]
  for i,n in enumerate(cats): c=ServiceCategory(name=n,slug=n.lower().replace(' ','-'),icon=['bi-lightning','bi-droplet','bi-snow','bi-disc','bi-box','bi-hammer','bi-brush','bi-moisture','bi-laptop','bi-stars','bi-bug','bi-plug'][i]); db.session.add(c); category_objs.append(c)
  admin=User(name='FixMate Admin',email='admin@example.com',role='admin',password_hash=generate_password_hash('Admin123!')); customer_users=[]
  db.session.add(admin)
  for i in range(10): u=User(name=f'Demo Customer {i+1}',email=f'customer{i+1}@example.com',role='customer',locality=localities[i]); u.password_hash=generate_password_hash('Customer123!'); db.session.add(u); customer_users.append(u)
  providers=[]
  for i in range(40):
   cat=category_objs[i%12]; u=User(name=f'{cat.name} Specialist {i+1}',email=f'provider{i+1}@example.com',role='provider',locality=localities[i%10]); u.password_hash=generate_password_hash('Provider123!'); p=ServiceProvider(user=u,business_name=f'{localities[i%10]} {cat.name} Care {i+1}',locality=localities[i%10],experience=2+i%16,bio=f'Fictional demo provider specializing in dependable {cat.name.lower()} services around Mumbai.',service_area=f'{localities[i%10]} and nearby areas',rating=round(3.5+(i%16)/10,1),approval_status='approved',lat=19.02+(i%10)*.03,lng=72.82+(i%8)*.04); db.session.add_all([u,p]); db.session.flush(); db.session.add_all([ProviderService(provider=p,category=cat,name=service_words[cat.name][0],price=199+i%8*50),ProviderService(provider=p,category=cat,name=service_words[cat.name][1],price=299+i%10*60)]); db.session.add_all([ProviderAvailability(provider_id=p.id,day=d,start_time='09:00',end_time='19:00',is_open=d not in ('Sunday',)) for d in ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']]); providers.append(p)
  db.session.commit()
  statuses=['Completed']*20+['Pending','Accepted','Rejected','In Progress','Cancelled']
  services=ProviderService.query.all()
  for i in range(25): db.session.add(Booking(customer_id=customer_users[i%10].id,provider_id=providers[i%40].id,service_id=services[i%len(services)].id,requested_at=datetime.now()+timedelta(days=(i%8)-2),address=f'{localities[i%10]}, Mumbai',description='Demo booking description for a household service request.',estimated_price=services[i%len(services)].price,status=statuses[i]))
  db.session.commit()
  completed=Booking.query.filter_by(status='Completed').all()
  for b in completed[:20]: db.session.add(Review(booking_id=b.id,customer_id=b.customer_id,provider_id=b.provider_id,rating=4+(b.id%2),comment='Sample testimonial: prompt and professional demo service.'))
  db.session.commit(); print('Seeded 12 categories, 40 providers, 10 customers, 25 bookings and reviews.')
if __name__=='__main__':
 parser=argparse.ArgumentParser(); parser.add_argument('--reset',action='store_true',help='Explicitly reset the local demo database'); seed(parser.parse_args().reset)
