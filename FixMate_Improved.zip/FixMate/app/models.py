from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from .extensions import db
class User(UserMixin,db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(120),nullable=False); email=db.Column(db.String(160),unique=True,nullable=False,index=True); password_hash=db.Column(db.String(255),nullable=False); role=db.Column(db.String(20),nullable=False,default="customer"); locality=db.Column(db.String(80)); phone=db.Column(db.String(40)); created_at=db.Column(db.DateTime,default=datetime.utcnow)
 provider=db.relationship("ServiceProvider",back_populates="user",uselist=False,cascade="all, delete-orphan")
 bookings=db.relationship("Booking",back_populates="customer",foreign_keys="Booking.customer_id")
 def set_password(self,p): self.password_hash=generate_password_hash(p)
 def check_password(self,p): return check_password_hash(self.password_hash,p)
class ServiceCategory(db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(80),unique=True,nullable=False); slug=db.Column(db.String(80),unique=True,nullable=False); icon=db.Column(db.String(40),default="bi-tools"); active=db.Column(db.Boolean,default=True)
 services=db.relationship("ProviderService",back_populates="category")
class ServiceProvider(db.Model):
 id=db.Column(db.Integer,primary_key=True); user_id=db.Column(db.Integer,db.ForeignKey("user.id"),unique=True,nullable=False); business_name=db.Column(db.String(140),nullable=False); locality=db.Column(db.String(80),nullable=False); city=db.Column(db.String(80),default="Mumbai"); experience=db.Column(db.Integer,default=1); bio=db.Column(db.Text); service_area=db.Column(db.String(180)); hours=db.Column(db.String(100),default="9:00 AM - 7:00 PM"); available=db.Column(db.Boolean,default=True); rating=db.Column(db.Float,default=4.0); lat=db.Column(db.Float); lng=db.Column(db.Float); approval_status=db.Column(db.String(20),default="pending"); is_demo=db.Column(db.Boolean,default=True)
 user=db.relationship("User",back_populates="provider"); services=db.relationship("ProviderService",back_populates="provider",cascade="all, delete-orphan"); bookings=db.relationship("Booking",back_populates="provider"); reviews=db.relationship("Review",back_populates="provider")
class ProviderService(db.Model):
 id=db.Column(db.Integer,primary_key=True); provider_id=db.Column(db.Integer,db.ForeignKey("service_provider.id"),nullable=False); category_id=db.Column(db.Integer,db.ForeignKey("service_category.id"),nullable=False); name=db.Column(db.String(140),nullable=False); price=db.Column(db.Integer,nullable=False)
 provider=db.relationship("ServiceProvider",back_populates="services"); category=db.relationship("ServiceCategory",back_populates="services")
class Booking(db.Model):
 id=db.Column(db.Integer,primary_key=True); customer_id=db.Column(db.Integer,db.ForeignKey("user.id"),nullable=False); provider_id=db.Column(db.Integer,db.ForeignKey("service_provider.id"),nullable=False); service_id=db.Column(db.Integer,db.ForeignKey("provider_service.id"),nullable=False); requested_at=db.Column(db.DateTime,nullable=False); address=db.Column(db.String(240),nullable=False); description=db.Column(db.Text,nullable=False); estimated_price=db.Column(db.Integer,nullable=False); status=db.Column(db.String(20),default="Pending",index=True); created_at=db.Column(db.DateTime,default=datetime.utcnow); updated_at=db.Column(db.DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)
 customer=db.relationship("User",back_populates="bookings",foreign_keys=[customer_id]); provider=db.relationship("ServiceProvider",back_populates="bookings"); service=db.relationship("ProviderService"); review=db.relationship("Review",back_populates="booking",uselist=False,cascade="all, delete-orphan")
class Review(db.Model):
 id=db.Column(db.Integer,primary_key=True); booking_id=db.Column(db.Integer,db.ForeignKey("booking.id"),unique=True,nullable=False); customer_id=db.Column(db.Integer,db.ForeignKey("user.id"),nullable=False); provider_id=db.Column(db.Integer,db.ForeignKey("service_provider.id"),nullable=False); rating=db.Column(db.Integer,nullable=False); comment=db.Column(db.Text,nullable=False); created_at=db.Column(db.DateTime,default=datetime.utcnow)
 booking=db.relationship("Booking",back_populates="review"); provider=db.relationship("ServiceProvider",back_populates="reviews")
class ProviderAvailability(db.Model):
 id=db.Column(db.Integer,primary_key=True); provider_id=db.Column(db.Integer,db.ForeignKey("service_provider.id"),nullable=False); day=db.Column(db.String(15),nullable=False); start_time=db.Column(db.String(10),default="09:00"); end_time=db.Column(db.String(10),default="19:00"); is_open=db.Column(db.Boolean,default=True)
class ContactMessage(db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(120),nullable=False); email=db.Column(db.String(160),nullable=False); message=db.Column(db.Text,nullable=False); created_at=db.Column(db.DateTime,default=datetime.utcnow)
