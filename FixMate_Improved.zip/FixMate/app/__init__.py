from flask import Flask, render_template
from config import Config
from .extensions import db,login_manager,csrf
from .models import User
def create_app(config_class=Config):
 app=Flask(__name__,instance_relative_config=True); app.config.from_object(config_class)
 import os; os.makedirs(app.instance_path,exist_ok=True)
 db.init_app(app); login_manager.init_app(app); csrf.init_app(app)
 @login_manager.user_loader
 def load_user(uid): return db.session.get(User,int(uid))
 from .routes import main, auth, customer, provider, admin
 app.register_blueprint(main); app.register_blueprint(auth,url_prefix="/auth"); app.register_blueprint(customer,url_prefix="/customer"); app.register_blueprint(provider,url_prefix="/provider"); app.register_blueprint(admin,url_prefix="/admin")
 @app.errorhandler(403)
 def e403(e): return render_template('error.html',code=403,message='You do not have permission to view this page.'),403
 @app.errorhandler(404)
 def e404(e): return render_template('error.html',code=404,message='The page you requested was not found.'),404
 @app.errorhandler(500)
 def e500(e): return render_template('error.html',code=500,message='Something went wrong. Please try again.'),500
 with app.app_context(): db.create_all()
 return app
