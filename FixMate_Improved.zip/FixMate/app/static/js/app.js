"use strict";

document.addEventListener("DOMContentLoaded", function () {

    // =====================================================
    // 1. MOBILE NAVIGATION MENU
    // =====================================================

    const menuToggle = document.getElementById("menuToggle");
    const navLinks = document.getElementById("navLinks");

    if (menuToggle && navLinks) {

        menuToggle.addEventListener("click", function () {
            const isOpen = navLinks.classList.toggle("open");

            menuToggle.setAttribute("aria-expanded", String(isOpen));
            menuToggle.textContent = isOpen ? "✕" : "☰";
        });

        navLinks.querySelectorAll("a").forEach(function (link) {

            link.addEventListener("click", function () {
                navLinks.classList.remove("open");
                menuToggle.setAttribute("aria-expanded", "false");
                menuToggle.textContent = "☰";
            });

        });

        window.addEventListener("resize", function () {

            if (window.innerWidth > 760) {
                navLinks.classList.remove("open");
                menuToggle.setAttribute("aria-expanded", "false");
                menuToggle.textContent = "☰";
            }

        });

    }


    // =====================================================
    // 2. PROFILE DROPDOWN
    // =====================================================

    const profileMenu = document.querySelector(".profile-menu");
    const profileTrigger = document.getElementById("profile-menu-trigger");
    const profileDropdown = document.getElementById("profileDropdown");

    if (profileMenu && profileTrigger && profileDropdown) {

        function closeProfileDropdown() {
            profileDropdown.hidden = true;
            profileTrigger.setAttribute("aria-expanded", "false");
        }

        function openProfileDropdown() {
            profileDropdown.hidden = false;
            profileTrigger.setAttribute("aria-expanded", "true");
        }

        profileTrigger.addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();

            const isOpen = !profileDropdown.hidden;

            if (isOpen) {
                closeProfileDropdown();
            } else {
                openProfileDropdown();
            }
        });

        // Close when the user clicks outside the profile menu.
        document.addEventListener("click", function (event) {

            if (!profileMenu.contains(event.target)) {
                closeProfileDropdown();
            }

        });

        // Close when the user presses Escape.
        document.addEventListener("keydown", function (event) {

            if (event.key === "Escape") {
                closeProfileDropdown();
                profileTrigger.focus();
            }

        });

        // Close after selecting a dropdown link.
        profileDropdown.querySelectorAll("a").forEach(function (link) {

            link.addEventListener("click", function () {
                closeProfileDropdown();
            });

        });

    }


    // =====================================================
    // 3. DISMISS FLASH NOTIFICATIONS
    // =====================================================

    const flashMessages = document.querySelectorAll(".flash-message");

    flashMessages.forEach(function (message) {

        const closeButton = message.querySelector(".flash-close");

        if (closeButton) {

            closeButton.addEventListener("click", function () {
                message.remove();
            });

        }

        window.setTimeout(function () {

            if (message.isConnected) {
                message.remove();
            }

        }, 5000);

    });


    // =====================================================
    // 4. REGISTRATION FORM VALIDATION
    // =====================================================

    const registerForm = document.getElementById("registerForm");

    if (registerForm) {

        const password = document.getElementById("password");
        const confirmPassword = document.getElementById("confirm_password");

        function validatePasswords() {

            if (!password || !confirmPassword) {
                return true;
            }

            if (confirmPassword.value !== password.value) {

                confirmPassword.setCustomValidity(
                    "Passwords do not match."
                );

                return false;
            }

            confirmPassword.setCustomValidity("");
            return true;

        }

        if (password && confirmPassword) {
            password.addEventListener("input", validatePasswords);
            confirmPassword.addEventListener("input", validatePasswords);
        }

        registerForm.addEventListener("submit", function (event) {

            if (!validatePasswords()) {
                event.preventDefault();
                confirmPassword.reportValidity();
            }

        });

    }


    // =====================================================
    // 5. GST NUMBER FORMATTING
    // =====================================================

    const gstInput = document.getElementById("gst_number");

    if (gstInput) {

        gstInput.addEventListener("input", function () {

            const cursorPosition = gstInput.selectionStart;

            gstInput.value = gstInput.value.toUpperCase();

            try {
                gstInput.setSelectionRange(
                    cursorPosition,
                    cursorPosition
                );
            } catch (error) {
                // Ignore cursor-position errors for unsupported inputs.
            }

        });

    }


    // =====================================================
    // 6. PIN CODE INPUT
    // =====================================================

    const pincodeInput = document.getElementById("pincode");

    if (pincodeInput) {

        pincodeInput.addEventListener("input", function () {

            pincodeInput.value = pincodeInput.value
                .replace(/\D/g, "")
                .slice(0, 6);

        });

    }


    // =====================================================
    // 7. MOBILE NUMBER INPUT
    // =====================================================

    const mobileInputs = document.querySelectorAll(
        'input[name="mobile"], input[name="business_phone"]'
    );

    mobileInputs.forEach(function (input) {

        input.addEventListener("input", function () {

            input.value = input.value
                .replace(/\D/g, "")
                .slice(0, 10);

        });

    });


    // =====================================================
    // 8. SERVICE EDIT AND CANCEL CONTROLS
    // =====================================================

    document.querySelectorAll(".service-edit-button").forEach(
        function (button) {

            button.addEventListener("click", function () {

                const serviceId = button.dataset.serviceId;

                if (!serviceId) {
                    return;
                }

                const displaySection = document.getElementById(
                    "service-display-" + serviceId
                );

                const editForm = document.getElementById(
                    "service-edit-form-" + serviceId
                );

                if (displaySection && editForm) {
                    displaySection.hidden = true;
                    editForm.hidden = false;

                    const firstInput = editForm.querySelector(
                        'input[name="service_name"]'
                    );

                    if (firstInput) {
                        firstInput.focus();
                    }
                }

            });

        }
    );

    document.querySelectorAll(".service-cancel-button").forEach(
        function (button) {

            button.addEventListener("click", function () {

                const serviceId = button.dataset.serviceId;

                if (!serviceId) {
                    return;
                }

                const displaySection = document.getElementById(
                    "service-display-" + serviceId
                );

                const editForm = document.getElementById(
                    "service-edit-form-" + serviceId
                );

                if (displaySection && editForm) {
                    editForm.hidden = true;
                    displaySection.hidden = false;
                }

            });

        }
    );


    // =====================================================
    // 9. SERVICE PRICING TYPE
    // =====================================================

    function updateServicePriceField(select) {

        const targetId = select.dataset.priceTarget;

        if (!targetId) {
            return;
        }

        const priceInput = document.getElementById(targetId);

        if (!priceInput) {
            return;
        }

        const isFixedPrice = select.value === "fixed";

        priceInput.disabled = !isFixedPrice;
        priceInput.required = isFixedPrice;

        if (!isFixedPrice) {
            priceInput.value = "";
        }

        const priceContainer = priceInput.closest(
            ".form-group, .form-field, .service-price-field"
        );

        if (priceContainer) {
            priceContainer.classList.toggle(
                "price-disabled",
                !isFixedPrice
            );
        }

    }

    document.querySelectorAll(".service-pricing-type").forEach(
        function (select) {

            select.addEventListener("change", function () {
                updateServicePriceField(select);
            });

            // Set the correct initial state when the page loads.
            updateServicePriceField(select);

        }
    );


    // =====================================================
    // 10. SERVICE DELETE CONFIRMATION
    // =====================================================

    document.querySelectorAll(".service-delete-form").forEach(
        function (form) {

            form.addEventListener("submit", function (event) {

                const confirmed = window.confirm(
                    "Are you sure you want to delete this service?"
                );

                if (!confirmed) {
                    event.preventDefault();
                }

            });

        }
    );

});