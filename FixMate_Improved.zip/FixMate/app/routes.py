from datetime import datetime
from functools import wraps
from flask import Blueprint,render_template,request,redirect,url_for,flash,abort
from flask_login import login_user,logout_user,current_user,login_required
from flask_wtf import FlaskForm
from wtforms import StringField,PasswordField,TextAreaField,SelectField,SubmitField,IntegerField
from wtforms.validators import DataRequired,Email,Length,NumberRange
from .extensions import db
from .models import *
main=Blueprint('main',__name__); auth=Blueprint('auth',__name__); customer=Blueprint('customer',__name__); provider=Blueprint('provider',__name__); admin=Blueprint('admin',__name__)
class LoginForm(FlaskForm): email=StringField('Email',validators=[DataRequired(),Email()]); password=PasswordField('Password',validators=[DataRequired()]); submit=SubmitField('Log in')
class RegisterForm(FlaskForm): name=StringField('Full name',validators=[DataRequired(),Length(min=2,max=120)]); email=StringField('Email',validators=[DataRequired(),Email()]); password=PasswordField('Password',validators=[DataRequired(),Length(min=6)]); locality=StringField('Locality'); submit=SubmitField('Create account')
class ContactForm(FlaskForm): name=StringField('Name',validators=[DataRequired()]); email=StringField('Email',validators=[DataRequired(),Email()]); message=TextAreaField('Message',validators=[DataRequired(),Length(min=10)]); submit=SubmitField('Send message')
def role_required(role):
 def deco(f):
  @wraps(f)
  @login_required
  def wrapped(*a,**kw):
   if current_user.role!=role: abort(403)
   return f(*a,**kw)
  return wrapped
 return deco
@main.route('/')
def home():
 cats=ServiceCategory.query.filter_by(active=True).limit(12).all(); providers=ServiceProvider.query.filter_by(approval_status='approved').order_by(ServiceProvider.rating.desc()).limit(8).all()
 return render_template('home.html',categories=cats,providers=providers,provider_count=ServiceProvider.query.count(),booking_count=Booking.query.count())
@main.route('/browse')
def browse():
 q=request.args.get('q','').strip(); category=request.args.get('category',''); locality=request.args.get('locality',''); sort=request.args.get('sort','rating')
 query=ServiceProvider.query.filter_by(approval_status='approved')
 if q: query=query.join(ServiceProvider.services).join(ProviderService.category).filter(db.or_(ServiceProvider.business_name.ilike(f'%{q}%'),ServiceProvider.locality.ilike(f'%{q}%'),ServiceCategory.name.ilike(f'%{q}%'))).distinct()
 if category: query=query.join(ServiceProvider.services, isouter=True).join(ProviderService.category,isouter=True).filter(ServiceCategory.slug==category)
 if locality: query=query.filter(ServiceProvider.locality.ilike(f'%{locality}%'))
 if sort=='price': query=query.join(ServiceProvider.services).order_by(ProviderService.price.asc())
 elif sort=='experience': query=query.order_by(ServiceProvider.experience.desc())
 elif sort=='reviews': query=query.outerjoin(ServiceProvider.reviews).group_by(ServiceProvider.id).order_by(db.func.count(Review.id).desc())
 else: query=query.order_by(ServiceProvider.rating.desc())
 return render_template('browse.html',providers=query.all(),categories=ServiceCategory.query.filter_by(active=True).all(),q=q,category=category,locality=locality,sort=sort)
@main.route('/provider/<int:provider_id>')
def profile(provider_id):
 p=db.get_or_404(ServiceProvider,provider_id); return render_template('provider_profile.html',provider=p)
@main.route('/about')
def about(): return render_template('about.html')
@main.route('/contact',methods=['GET','POST'])
def contact():
 form=ContactForm()
 if form.validate_on_submit(): db.session.add(ContactMessage(name=form.name.data,email=form.email.data,message=form.message.data)); db.session.commit(); flash('Thanks — your message has been saved.','success'); return redirect(url_for('main.contact'))
 return render_template('contact.html',form=form)
@auth.route('/login',methods=['GET','POST'])
def login():
 form=LoginForm()
 if form.validate_on_submit():
  u=User.query.filter_by(email=form.email.data.lower()).first()
  if u and u.check_password(form.password.data): login_user(u); return redirect(request.args.get('next') or url_for('main.home'))
  flash('Invalid email or password.','danger')
 return render_template('auth.html',form=form,title='Log in',register=False)
@auth.route('/register',methods=['GET','POST'])
def register():
 form=RegisterForm()
 if form.validate_on_submit():
  if User.query.filter_by(email=form.email.data.lower()).first(): flash('An account with that email already exists.','warning')
  else:
   u=User(name=form.name.data,email=form.email.data.lower(),locality=form.locality.data,role='customer'); u.set_password(form.password.data); db.session.add(u); db.session.commit(); login_user(u); flash('Welcome to FixMate!','success'); return redirect(url_for('customer.dashboard'))
 return render_template('auth.html',form=form,title='Create customer account',register=True)
@auth.route('/provider-register',methods=['GET','POST'])
def provider_register():
 form=RegisterForm()
 if form.validate_on_submit():
  if User.query.filter_by(email=form.email.data.lower()).first(): flash('An account with that email already exists.','warning')
  else:
   u=User(name=form.name.data,email=form.email.data.lower(),locality=form.locality.data,role='provider'); u.set_password(form.password.data); p=ServiceProvider(user=u,business_name=form.name.data+' Services',locality=form.locality.data or 'Mumbai',approval_status='pending',is_demo=False,bio='New FixMate provider profile awaiting admin approval.'); db.session.add_all([u,p]); db.session.commit(); flash('Provider account created and sent for admin approval.','success'); return redirect(url_for('auth.login'))
 return render_template('auth.html',form=form,title='Register as a provider',register=True,provider=True)
@auth.route('/logout')
@login_required
def logout(): logout_user(); return redirect(url_for('main.home'))
@customer.route('/dashboard')
@role_required('customer')
def dashboard(): return render_template('customer_dashboard.html',bookings=Booking.query.filter_by(customer_id=current_user.id).order_by(Booking.created_at.desc()).all())
@customer.route('/book/<int:provider_id>',methods=['GET','POST'])
@role_required('customer')
def book(provider_id):
 p=db.get_or_404(ServiceProvider,provider_id); services=p.services
 if request.method=='POST':
  try: service=db.get_or_404(ProviderService,int(request.form['service_id'])); when=datetime.fromisoformat(request.form['requested_at'])
  except (KeyError,ValueError): flash('Please provide a valid date and service.','danger'); return render_template('booking.html',provider=p)
  b=Booking(customer_id=current_user.id,provider_id=p.id,service_id=service.id,requested_at=when,address=request.form['address'],description=request.form['description'],estimated_price=service.price); db.session.add(b); db.session.commit(); flash('Booking request submitted.','success'); return redirect(url_for('customer.bookings'))
 return render_template('booking.html',provider=p)
@customer.route('/bookings')
@role_required('customer')
def bookings(): return render_template('bookings.html',bookings=Booking.query.filter_by(customer_id=current_user.id).order_by(Booking.created_at.desc()).all())
@customer.route('/booking/<int:booking_id>/review',methods=['POST'])
@role_required('customer')
def review(booking_id):
 b=db.get_or_404(Booking,booking_id)
 if b.customer_id!=current_user.id or b.status!='Completed' or b.review: abort(403)
 r=Review(booking_id=b.id,customer_id=current_user.id,provider_id=b.provider_id,rating=max(1,min(5,int(request.form.get('rating',5)))),comment=request.form.get('comment','').strip()); db.session.add(r); db.session.commit(); flash('Review submitted.','success'); return redirect(url_for('customer.bookings'))
@provider.route('/dashboard')
@role_required('provider')
def dashboard():
 p=current_user.provider
 if not p: abort(404)
 return render_template('provider_dashboard.html',provider=p,bookings=Booking.query.filter_by(provider_id=p.id).order_by(Booking.requested_at.desc()).all())
@provider.route('/booking/<int:booking_id>/<action>',methods=['POST'])
@role_required('provider')
def update_booking(booking_id,action):
 b=db.get_or_404(Booking,booking_id)
 if not current_user.provider or b.provider_id!=current_user.provider.id: abort(403)
 transitions={'accept':('Pending','Accepted'),'reject':('Pending','Rejected'),'start':('Accepted','In Progress'),'complete':('In Progress','Completed')}
 if action not in transitions or b.status!=transitions[action][0]: flash('That status transition is not allowed.','danger')
 else: b.status=transitions[action][1]; db.session.commit(); flash('Booking status updated.','success')
 return redirect(url_for('provider.dashboard'))
@admin.route('/dashboard')
@role_required('admin')
def dashboard(): return render_template('admin_dashboard.html',users=User.query.count(),providers=ServiceProvider.query.count(),categories=ServiceCategory.query.count(),bookings=Booking.query.count(),reviews=Review.query.count(),queue=ServiceProvider.query.filter_by(approval_status='pending').all(),recent=Booking.query.order_by(Booking.created_at.desc()).limit(8).all())
@admin.route('/provider/<int:pid>/<action>',methods=['POST'])
@role_required('admin')
def provider_action(pid,action):
 p=db.get_or_404(ServiceProvider,pid)
 if action in ('approve','reject','suspend'): p.approval_status={'approve':'approved','reject':'rejected','suspend':'suspended'}[action]; db.session.commit(); flash('Provider status updated.','success')
 return redirect(url_for('admin.dashboard'))

@customer.route('/profile', methods=['GET', 'POST'])
@role_required('customer')
def profile_settings():
 if request.method == 'POST':
  current_user.name=request.form.get('name','').strip()[:120]; current_user.locality=request.form.get('locality','').strip()[:80]; current_user.phone=request.form.get('phone','').strip()[:40]
  if not current_user.name: flash('Name is required.','danger')
  else: db.session.commit(); flash('Profile updated.','success'); return redirect(url_for('customer.profile_settings'))
 return render_template('profile_settings.html',user=current_user)

@customer.route('/booking/<int:booking_id>/cancel', methods=['POST'])
@role_required('customer')
def cancel_booking(booking_id):
 b=db.get_or_404(Booking,booking_id)
 if b.customer_id!=current_user.id: abort(403)
 if b.status not in ('Pending','Accepted'): flash('This booking cannot be cancelled at its current status.','warning')
 else: b.status='Cancelled'; db.session.commit(); flash('Booking cancelled.','success')
 return redirect(url_for('customer.bookings'))

@provider.route('/settings', methods=['GET', 'POST'])
@role_required('provider')
def settings():
 p=current_user.provider
 if not p: abort(404)
 if request.method=='POST':
  p.business_name=request.form.get('business_name','').strip()[:140]; p.locality=request.form.get('locality','').strip()[:80]; p.service_area=request.form.get('service_area','').strip()[:180]; p.hours=request.form.get('hours','').strip()[:100]; p.bio=request.form.get('bio','').strip(); p.available=request.form.get('available')=='1'
  if not p.business_name or not p.locality: flash('Business name and locality are required.','danger')
  else: db.session.commit(); flash('Provider profile updated.','success'); return redirect(url_for('provider.settings'))
 return render_template('provider_settings.html',provider=p)

@admin.route('/users')
@role_required('admin')
def users(): return render_template('admin_users.html',users=User.query.order_by(User.created_at.desc()).all())

@admin.route('/categories', methods=['GET', 'POST'])
@role_required('admin')
def categories():
 if request.method=='POST':
  name=request.form.get('name','').strip()[:80]; slug=name.lower().replace(' ','-')
  if name and not ServiceCategory.query.filter_by(slug=slug).first(): db.session.add(ServiceCategory(name=name,slug=slug,icon='bi-tools')); db.session.commit(); flash('Category added.','success')
  else: flash('Enter a new category name.','warning')
 return render_template('admin_categories.html',categories=ServiceCategory.query.order_by(ServiceCategory.name).all())

@admin.route('/booking/<int:booking_id>/<action>', methods=['POST'])
@role_required('admin')
def booking_action(booking_id,action):
 b=db.get_or_404(Booking,booking_id)
 if action=='cancel' and b.status not in ('Completed','Cancelled','Rejected'): b.status='Cancelled'; db.session.commit(); flash('Booking cancelled by admin.','success')
 return redirect(url_for('admin.dashboard'))
